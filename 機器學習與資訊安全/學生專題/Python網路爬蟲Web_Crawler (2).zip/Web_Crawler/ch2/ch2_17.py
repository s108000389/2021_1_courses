# ch2_17.py
from datetime import datetime

dateObj = datetime.strptime('2017/1/1', '%Y/%m/%d')
print(dateObj)


