# ch3_1.py
import webbrowser
webbrowser.open('http://www.mcut.edu.tw')




