# ch12_7.py
import twstock
stock2330 = twstock.Stock("2330")

print("股票代號   : ", stock2330.sid)
print("股票收盤價 : ", stock2330.price)

