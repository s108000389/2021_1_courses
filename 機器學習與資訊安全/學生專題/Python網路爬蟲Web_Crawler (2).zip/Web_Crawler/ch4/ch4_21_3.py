# ch4_21_3.py
from datetime import datetime

timeStop = datetime(2019,7,28,19,50,50)
while datetime.now() < timeStop:
    print("Program is sleeping.", end="")
print("Wake up")




















