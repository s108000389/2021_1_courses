# ch4_21_4.py
from datetime import datetime, timedelta

deltaTime = timedelta(days=3,hours=5,minutes=8,seconds=10)
print(deltaTime.days, deltaTime.seconds, deltaTime.microseconds)





















